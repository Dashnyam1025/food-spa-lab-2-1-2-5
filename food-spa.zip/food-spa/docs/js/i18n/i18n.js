import { translations } from "./translations.js";
let language = "mn";
try { language = localStorage.getItem("language") || "mn"; } catch {}
if (!Object.hasOwn(translations, language)) language = "mn";

export function getCurrentLanguage() { return language; }
export function setLanguage(next) {
  if (!Object.hasOwn(translations, next)) return;
  language = next;
  try { localStorage.setItem("language", language); } catch {}
  window.dispatchEvent(new Event("languagechange"));
}
export function toggleLanguage() { setLanguage(language === "mn" ? "en" : "mn"); }
export function t(path) {
  return path.split(".").reduce((value, key) => value?.[key], translations[language]) ?? path;
}
