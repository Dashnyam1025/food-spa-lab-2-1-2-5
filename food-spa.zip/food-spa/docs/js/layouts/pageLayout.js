import { t } from "../i18n/i18n.js";
export function renderPageLayout({ id, title, lead = "", content = "", overview = false }) {
  document.title = `${title.replaceAll("\n", " ")} | ${t("brand")}`;
  return `<section class="section page-section ${overview ? "overview" : ""}" id="${id}"><div class="container"><div class="eyebrow"><span></span>${t("common.label")}</div>${content ? `<h1 class="page-title ${overview ? "is-sr-only" : ""}">${title.replaceAll("\n", "<br>")}</h1>` : `<h1 class="page-title">${title}</h1>`}${lead ? `<p class="page-lead">${lead}</p>` : ""}${content}<footer class="page-footer"><span>${t("brandSub")}</span><span>${t("common.stage")}</span></footer></div></section>`;
}
