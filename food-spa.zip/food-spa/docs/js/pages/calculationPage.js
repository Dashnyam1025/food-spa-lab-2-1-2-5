import { t } from "../i18n/i18n.js";
import { renderPageLayout } from "../layouts/pageLayout.js";
export function renderCalculationPage() {
  document.getElementById("app").innerHTML = renderPageLayout({ id: "calculation", title: t("calculation.title"), lead: t("calculation.lead"), content: `<div class="detail-body"><p>${t("calculation.body")}</p><h2>${t("common.next")}</h2><p>${t("calculation.next")}</p></div><a class="button is-primary" href="#/overview">${t("common.back")}</a>` });
}
