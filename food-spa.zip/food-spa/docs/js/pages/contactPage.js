import { t } from "../i18n/i18n.js";
import { renderPageLayout } from "../layouts/pageLayout.js";
export function renderContactPage() {
  document.getElementById("app").innerHTML = renderPageLayout({ id: "contact", title: t("contact.title"), lead: t("contact.lead"), content: `<div class="detail-body"><p>${t("contact.body")}</p><h2>${t("common.next")}</h2><p>${t("contact.next")}</p></div><a class="button is-primary" href="#/overview">${t("common.back")}</a>` });
}
