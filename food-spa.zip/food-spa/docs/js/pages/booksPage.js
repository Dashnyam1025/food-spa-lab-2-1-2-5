import { t } from "../i18n/i18n.js";
import { renderPageLayout } from "../layouts/pageLayout.js";
export function renderBooksPage() {
  document.getElementById("app").innerHTML = renderPageLayout({ id: "books", title: t("books.title"), lead: t("books.lead"), content: `<div class="detail-body"><p class="stage">${t("books.author")}</p><h2>${t("books.book")}</h2><p>${t("books.body")}</p><h2>${t("common.next")}</h2><p>${t("books.next")}</p></div><a class="button is-primary" href="#/overview">${t("common.back")}</a>` });
}
