import { cp, mkdir } from "node:fs/promises";
await mkdir(new URL("../docs/", import.meta.url), { recursive: true });
await cp(new URL("../src/", import.meta.url), new URL("../docs/", import.meta.url), { recursive: true });
console.log("docs/ бэлэн. GitHub Pages: branch main, folder /docs.");
