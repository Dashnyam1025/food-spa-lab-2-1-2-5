import { t } from "../i18n/i18n.js";
import { renderPageLayout } from "../layouts/pageLayout.js";
export function renderSearchPage() {
  document.getElementById("app").innerHTML = renderPageLayout({ id: "search", title: t("search.title"), lead: t("search.lead"), content: `<div class="detail-body"><p>${t("search.body")}</p><h2>${t("common.next")}</h2><p>${t("search.next")}</p></div><a class="button is-primary" href="#/overview">${t("common.back")}</a>` });
}
