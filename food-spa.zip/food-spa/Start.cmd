@echo off
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel%==0 (
  start "" http://127.0.0.1:5500/#/overview
  node tools/server.mjs
) else (
  if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
    start "" http://127.0.0.1:5500/#/overview
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" tools/server.mjs
  ) else (
    echo Node.js is required. Install Node.js or use VS Code Live Server.
    pause
  )
)
