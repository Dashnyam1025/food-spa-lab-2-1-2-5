import { t } from "../i18n/i18n.js";
import { renderPageLayout } from "../layouts/pageLayout.js";
export function renderNotFoundPage() {
  document.getElementById("app").innerHTML = renderPageLayout({ id: "not-found", title: `404 · ${t("notFound.title")}`, lead: t("notFound.lead"), content: `<a class="button is-primary" href="#/overview">${t("common.back")}</a>` });
}
