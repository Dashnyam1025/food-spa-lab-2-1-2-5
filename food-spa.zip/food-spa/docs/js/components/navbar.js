import { t, toggleLanguage } from "../i18n/i18n.js";

export function renderNavbar() {
  const links = ["overview", "search", "calculation", "books", "contact"];
  return `<header class="site-header"><nav class="navbar container" aria-label="Main navigation">
    <div class="navbar-brand"><a class="brand" href="#/overview"><img src="./img/logo.svg" alt="" width="44" height="44"><span><strong>${t("brand")}</strong><small>${t("brandSub")}</small></span></a>
    <button class="navbar-burger" type="button" aria-label="Menu" aria-expanded="false" aria-controls="topNavbar"><span></span><span></span><span></span><span></span></button></div>
    <div class="navbar-menu" id="topNavbar"><div class="navbar-end">${links.map(key => `<a class="navbar-item" data-route href="#/${key}">${t(`nav.${key}`)}</a>`).join("")}<button class="button language-button" type="button" id="langToggle" aria-label="${t("nav.language") === "EN" ? "Switch to English" : "Монгол хэл рүү солих"}">${t("nav.language")}</button></div></div>
  </nav></header>`;
}
export function initNavbar(root) {
  const burger = root.querySelector(".navbar-burger");
  const menu = root.querySelector("#topNavbar");
  function close() { burger.classList.remove("is-active"); menu.classList.remove("is-active"); burger.setAttribute("aria-expanded", "false"); }
  burger.addEventListener("click", () => {
    const open = burger.getAttribute("aria-expanded") !== "true";
    burger.classList.toggle("is-active", open); menu.classList.toggle("is-active", open); burger.setAttribute("aria-expanded", String(open));
  });
  root.querySelectorAll("[data-route]").forEach(link => link.addEventListener("click", close));
  root.querySelector("#langToggle").addEventListener("click", toggleLanguage);
  root.addEventListener("keydown", event => { if (event.key === "Escape") { close(); burger.focus(); } });
}
export function mountNavbar(root) { if (root) { root.innerHTML = renderNavbar(); initNavbar(root); } }
