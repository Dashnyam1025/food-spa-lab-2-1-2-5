import { mountNavbar } from "./components/navbar.js";
import { initRouter, renderCurrentRoute } from "./router.js";
import { routes } from "./routes.js";
import { getCurrentLanguage } from "./i18n/i18n.js";

function updateLanguage() {
  document.documentElement.lang = getCurrentLanguage();
  mountNavbar(document.getElementById("navbar"));
  renderCurrentRoute(routes);
}

document.documentElement.lang = getCurrentLanguage();
mountNavbar(document.getElementById("navbar"));
initRouter(routes);
window.addEventListener("languagechange", updateLanguage);
document.querySelector(".skip-link").addEventListener("click", event => {
  event.preventDefault();
  document.getElementById("main").focus();
});
