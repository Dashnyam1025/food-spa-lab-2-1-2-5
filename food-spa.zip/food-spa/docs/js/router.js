export function getRoute() {
  return window.location.hash || "#/overview";
}

export function renderCurrentRoute(routes) {
  const hash = getRoute();
  const page = Object.hasOwn(routes, hash) ? routes[hash] : routes["#/404"];
  page();
  document.querySelectorAll("[data-route]").forEach((link) => {
    const active = link.getAttribute("href") === hash;
    link.classList.toggle("is-current", active);
    if (active) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
}

export function initRouter(routes) {
  const render = () => renderCurrentRoute(routes);
  window.addEventListener("hashchange", render);
  render();
}
